package com.example.tourism;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Countries extends AppCompatActivity {
    Button Saudi,France,Britain,Italy,UAE,butt_Egypt;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contries);

        Saudi = findViewById(R.id.Saudi);
        Saudi.setTag("Saudi");

        France = findViewById(R.id.France);
        France.setTag("France");

        Britain = findViewById(R.id.Britain);
        Britain.setTag("Britain");

        Italy = findViewById(R.id.Italy);
        Italy.setTag("Italy");
        UAE = findViewById(R.id.UAE);
        UAE.setTag("UAE");
        butt_Egypt = findViewById(R.id.butt_Egypt);
        butt_Egypt.setTag("Egypt");
    }
    public void onCountryButtonClick(View view) {
        String countryTag = (String) view.getTag();
        Intent intent = new Intent(this, Details.class);
        intent.putExtra("countryTag", countryTag);
        startActivity(intent);
        // finish();
    }
}