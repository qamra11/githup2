package com.example.tourism;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;


public class Details extends AppCompatActivity {
//    String desc1,desc2,desc3,desc4,desc5,desc6;
//    String cety1,city2,city3,city4,city5,city6,city7,city8,city9,city10,city12;

    TextView description, city1,city,description2, decsplase,discplase2;
    ImageView image1 ,image2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        description = findViewById(R.id.description);
        discplase2 = findViewById(R.id.descplase2);
        city = findViewById(R.id.city);
        city1 = findViewById(R.id.city2);
        decsplase = findViewById(R.id.descplase);
        discplase2 = findViewById(R.id.descplase2);
        image1 = findViewById(R.id.image);
        image2 = findViewById(R.id.image2);
        Intent intent = getIntent();

        if (intent != null) {
            String countryTag = intent.getStringExtra("countryTag");
            if(countryTag.equals("Saudi")){
                desplayPlaseTourismSaudi();
            } else if (countryTag.equals("France")) {
                desplayPlaseTourismFrance();
            }
            else if (countryTag.equals("Britain")) {
                desplayPlaseTourismBritain();
            }
            else if (countryTag.equals("Italy")) {
                desplayPlaseTourismItaly();
            }
            else if (countryTag.equals("UAE")) {
                desplayPlaseTourismUAE();
            }
            else if (countryTag.equals("Egypt")) {
                desplayPlaseTourismEgypt();
            }
        }

    }

    private void desplayPlaseTourismSaudi() {
        description.setText("Saudi Arabia is a fascinating tourist destination, known for its rich history, ancient culture, and diverse natural beauty");
        image1.setImageResource(R.drawable.s1);
        city.setText("1-Riyadh");
        decsplase.setText("the capital city of Saudi Arabia, is one of the prominent tourist cities in the country. It is home to several cultural and heritage landmarks, such as Kingdom Centre");
        city1.setText("2- Jeddah");
        discplase2.setText("i" +
                "s another fantastic tourist destination in Saudi Arabia. It is renowned for its beautiful corniche, which stretches along the Red Sea and offers stunning views.");
        image2.setImageResource(R.drawable.s2);
    }

    private void desplayPlaseTourismFrance() {
        description.setText("France is a popular tourist destination with many magnificent landmarks. Here are two of the most prominent tourist attractions in France:");
        image1.setImageResource(R.drawable.f1);
        city.setText("1- Paris:");
        decsplase.setText("Paris is the capital city of France and a famous tourist destination. It is a city rich in history and culture.");
        city1.setText("2- Cannes :");
        discplase2.setText("Cannes is a stunning coastal city located on the French Riviera. It is famous for its beautiful beaches and breathtaking landscapes.");
        image2.setImageResource(R.drawable.f2);
    }
    private void desplayPlaseTourismBritain() {
        description.setText("Britain, officially known as the United Kingdom, is a renowned tourist destination that attracts visitors from all over the world, and a wide array of magnificent tourist attractions. Here is some information about Britain as a tourist spot");
        image1.setImageResource(R.drawable.b1);
        city.setText("1- London");
        decsplase.setText(" London, the capital and largest city of Britain, is a fantastic tourist destination. Its famous landmarks include the iconic Big Ben clock tower.");
        city1.setText("2- Manchester");
        discplase2.setText("Manchester is a fantastic city located in northwest England and is an exciting tourist destination.");
        image2.setImageResource(R.drawable.b2);
    }
    private void desplayPlaseTourismItaly() {
        description.setText("Italy is a wonderful tourist destination that attracts millions of visitors each year. Here is some information about Italy as a tourist spot");
        image1.setImageResource(R.drawable.i1);
        city.setText("1- Rome:");
        decsplase.setText(" Rome is the capital city of Italy and a significant historical destination.It features iconic landmarks such as the Colosseum.");
        city1.setText("2- Tower of pisa :");
        discplase2.setText("The Leaning Tower of Pisa is a famous leaning tower located in the city of Pisa in the Tuscany region of Italy.");
        image2.setImageResource(R.drawable.i2);
    }
    private void desplayPlaseTourismUAE() {
        description.setText("The United Arab Emirates is a country located in the Arabian Peninsula in the Middle East. It is a popular and diverse tourist destination");
        image1.setImageResource(R.drawable.u1);
        city.setText("1-Dubai");
        decsplase.setText(" Dubai is one of the top tourist destinations in the United Arab Emirates. It is famous for its towering skyscrapers like the Burj Khalifa.");
        city1.setText("2- Abu Dhabi");
        discplase2.setText("the capital city, is also an important tourist destination. It is renowned for the Sheikh Zayed Grand Mosque.");
        image2.setImageResource(R.drawable.u2);
    }
    private void desplayPlaseTourismEgypt() {
        description.setText("Egypt is a popular and beloved tourist destination in North Africa.");
        image1.setImageResource(R.drawable.e1);
        city.setText("1- Cairo");
        decsplase.setText("the capital city of Egypt, is a major tourist destination. Visitors can explore the iconic Giza.");
        city1.setText("2- Luxor");
        discplase2.setText("destination in Egypt, where visitors can explore the remnants of the ancient Pharaonic civilization.");
        image2.setImageResource(R.drawable.e2);
    }
}